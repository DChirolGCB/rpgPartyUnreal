#include "HexGridManager.h"
#include "Engine/Blueprint.h"
#include "Engine/BlueprintGeneratedClass.h"

// Forward declaration pour BP_HexTile
class ABP_HexTile_C;

const TArray<FHexAxialCoordinates> UHexGridManager::HexDirections = {
    FHexAxialCoordinates(1, 0), FHexAxialCoordinates(1, -1), FHexAxialCoordinates(0, -1),
    FHexAxialCoordinates(-1, 0), FHexAxialCoordinates(-1, 1), FHexAxialCoordinates(0, 1)
};

UHexGridManager::UHexGridManager()
{
    PrimaryComponentTick.bCanEverTick = false;
}

void UHexGridManager::BeginPlay()
{
    Super::BeginPlay();
    HexTiles.Reserve(1000);
}

void UHexGridManager::RegisterHexTile(ABP_HexTile* Tile, const FHexAxialCoordinates& Coords)
{
    if (Tile)
    {
        HexTiles.Add(Coords, Tile);
        NeighborCache.Remove(Coords);
    }
}

ABP_HexTile* UHexGridManager::GetHexTile(const FHexAxialCoordinates& Coords) const
{
    if (const TWeakObjectPtr<ABP_HexTile>* TilePtr = HexTiles.Find(Coords))
    {
        return TilePtr->Get();
    }
    return nullptr;
}

TArray<FHexAxialCoordinates> UHexGridManager::GetNeighbors(const FHexAxialCoordinates& Coords) const
{
    if (const TArray<FHexAxialCoordinates>* CachedNeighbors = NeighborCache.Find(Coords))
    {
        return *CachedNeighbors;
    }
    
    TArray<FHexAxialCoordinates> Neighbors;
    for (const auto& Direction : HexDirections)
    {
        FHexAxialCoordinates NeighborCoord(Coords.Q + Direction.Q, Coords.R + Direction.R);
        if (GetHexTile(NeighborCoord))
        {
            Neighbors.Add(NeighborCoord);
        }
    }
    
    NeighborCache.Add(Coords, Neighbors);
    return Neighbors;
}

bool UHexGridManager::IsWalkable(const FHexAxialCoordinates& Coords) const
{
    if (ABP_HexTile* Tile = GetHexTile(Coords))
    {
        return Tile->IsWalkable;
    }
    return false;
}

FHexAxialCoordinates UHexGridManager::OffsetToAxial(int32 X, int32 Y) const
{
    int32 Q = X - (Y - (Y & 1)) / 2;
    int32 R = Y;
    return FHexAxialCoordinates(Q, R);
}