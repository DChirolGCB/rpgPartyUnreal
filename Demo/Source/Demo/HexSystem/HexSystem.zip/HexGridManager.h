#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "HexCoordinates.h"
#include "HexGridManager.generated.h"
#include "Engine/Engine.h"

// Forward declaration pour votre BP_HexTile
UCLASS()
class ABP_HexTile_C : public AActor
{
    GENERATED_BODY()
public:
    // Déclaration minimale - remplacez par vos propriétés réelles
    UPROPERTY(BlueprintReadWrite, EditAnywhere)
    int32 X;
    
    UPROPERTY(BlueprintReadWrite, EditAnywhere)
    int32 Y;
    
    UPROPERTY(BlueprintReadWrite, EditAnywhere)
    bool IsWalkable;
};

UCLASS(BlueprintType, ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class DEMO_API UHexGridManager : public UActorComponent
{
    GENERATED_BODY()

public:
    UHexGridManager();

protected:
    UPROPERTY()
    TMap<FHexAxialCoordinates, TWeakObjectPtr<ABP_HexTile_C>> HexTiles;
    
    mutable TMap<FHexAxialCoordinates, TArray<FHexAxialCoordinates>> NeighborCache;
    static const TArray<FHexAxialCoordinates> HexDirections;

public:
    UFUNCTION(BlueprintCallable, Category = "Hex Grid")
    void RegisterHexTile(ABP_HexTile_C* Tile, const FHexAxialCoordinates& Coords);
    
    UFUNCTION(BlueprintCallable, Category = "Hex Grid")
    ABP_HexTile_C* GetHexTile(const FHexAxialCoordinates& Coords) const;
    
    UFUNCTION(BlueprintCallable, Category = "Hex Grid")
    TArray<FHexAxialCoordinates> GetNeighbors(const FHexAxialCoordinates& Coords) const;
    
    UFUNCTION(BlueprintCallable, Category = "Hex Grid")
    bool IsWalkable(const FHexAxialCoordinates& Coords) const;
    
    UFUNCTION(BlueprintCallable, Category = "Hex Grid")
    FHexAxialCoordinates OffsetToAxial(int32 X, int32 Y) const;

protected:
    virtual void BeginPlay() override;
};